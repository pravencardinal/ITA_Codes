"""
ga_engine.py

Production-ready Genetic Algorithm engine.
Fully config-driven.
"""

from dataclasses import dataclass, field
from typing import Callable, List, Tuple
import numpy as np
import random
import logging
import os
from concurrent.futures import ProcessPoolExecutor, as_completed

from config import GAConfig
import fitness as fitness_mod
from logger_utils import log_execution
from data_io import save_checkpoint

logger = logging.getLogger(__name__)

FitnessFn = Callable[[np.ndarray, dict], tuple]


@dataclass
class Individual:
    gene_list: np.ndarray
    processed: dict
    fitness_value: tuple = field(init=False, default=None)
    fitness_function: FitnessFn = None

    def compute_fitness(self):
        if self.fitness_function is None:
            raise RuntimeError("Fitness function not set.")
        self.fitness_value = self.fitness_function(self.gene_list, self.processed)
        return self.fitness_value

    @property
    def fitness(self):
        return self.fitness_value if self.fitness_value else self.compute_fitness()

    @classmethod
    def set_fitness_function(cls, fn: FitnessFn):
        cls.fitness_function = fn

    @classmethod
    def generate_random(cls, processed: dict):
        data = processed["dat"]
        choices = data['lvl5_int']
        return cls(choices, processed)


class GAEngine:

    def __init__(self, config: GAConfig, processed_data: dict):
        self.cfg = config
        self.processed = processed_data

        random.seed(self.cfg.SEED)
        np.random.seed(self.cfg.SEED)

        self.population: List[Individual] = []
        self.best_individual: Individual = None

    @log_execution("ga_engine", "initialize_population", "Initialize and evaluate population")
    def initialize_population(self):
        self.population = [
            Individual.generate_random(self.processed)
            for _ in range(self.cfg.POPULATION_SIZE)
        ]
        self.evaluate_population(self.population)

    @log_execution("ga_engine", "evaluate_population", "Evaluate population fitness")
    def evaluate_population(self, population: List[Individual]):

        if self.cfg.PARALLEL_EVAL:
            with ProcessPoolExecutor() as exe:
                futures = {
                    exe.submit(fitness_mod.fitness_function, ind.gene_list, self.processed): ind
                    for ind in population
                }
                for fut in as_completed(futures):
                    ind = futures[fut]
                    ind.fitness_value = fut.result()
        else:
            for ind in population:
                ind.compute_fitness()

    def select(self) -> List[Individual]:
        sorted_pop = sorted(self.population, key=lambda i: i.fitness[3], reverse=True)
        elite = sorted_pop[:self.cfg.ELITE_SIZE]

        fitness_scores = np.array([max(0.0, ind.fitness[3]) for ind in sorted_pop])
        total = fitness_scores.sum()

        if total == 0:
            return elite + random.sample(sorted_pop[self.cfg.ELITE_SIZE:], len(sorted_pop) - self.cfg.ELITE_SIZE)

        probs = fitness_scores / total
        n_to_select = len(sorted_pop) - self.cfg.ELITE_SIZE
        chosen_idx = np.random.choice(range(len(sorted_pop)), size=n_to_select, replace=True, p=probs)

        return elite + [sorted_pop[i] for i in chosen_idx]

    def crossover(self, parents: List[Individual]) -> List[Individual]:
        children = []

        for a, b in zip(parents[::2], parents[1::2]):
            if random.random() < self.cfg.CROSSOVER_PROBABILITY:
                mask = np.random.rand(len(a.gene_list)) > 0.5
                child1 = np.where(mask, a.gene_list, b.gene_list)
                child2 = np.where(mask, b.gene_list, a.gene_list)
                children.append(Individual(child1, self.processed))
                children.append(Individual(child2, self.processed))
            else:
                children.extend([a, b])

        return children

    def mutate(self, population: List[Individual]) -> List[Individual]:
        mutated = []

        for ind in population:
            if random.random() < self.cfg.MUTATION_PROBABILITY:
                new_genes = ind.gene_list.copy()
                n_mut = max(1, int(0.01 * new_genes.size))
                idxs = np.random.choice(new_genes.size, n_mut, replace=False)
                for idx in idxs:
                    new_genes[idx] = np.random.choice(self.processed["n_lvl5_unq"])
                mutated.append(Individual(new_genes, self.processed))
            else:
                mutated.append(ind)

        return mutated

    @log_execution("ga_engine", "run", "Main GA loop")
    def run(self) -> Tuple[Individual, dict]:

        if not self.population:
            self.initialize_population()

        best = max(self.population, key=lambda i: i.fitness[3])
        stats = {"best_per_gen": [], "avg_per_gen": []}

        for gen in range(1, self.cfg.MAX_GENERATIONS + 1):

            parents = self.select()
            children = self.crossover(parents)
            next_pop = self.mutate(children)
            self.evaluate_population(next_pop)

            self.population = next_pop

            avg_fit = float(np.mean([ind.fitness[3] for ind in self.population]))
            best = max(self.population, key=lambda i: i.fitness[3])

            stats["best_per_gen"].append(float(best.fitness[3]))
            stats["avg_per_gen"].append(avg_fit)

            if gen % self.cfg.CHECKPOINT_FREQ == 0:
                os.makedirs(self.cfg.CHECKPOINT_DIR, exist_ok=True)
                save_checkpoint(
                    self.population,
                    os.path.join(self.cfg.CHECKPOINT_DIR, f"ga_checkpoint_gen_{gen}.pkl")
                )

        self.best_individual = best
        return best, stats
