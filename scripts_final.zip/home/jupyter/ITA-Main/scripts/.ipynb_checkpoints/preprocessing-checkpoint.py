"""
preprocessing.py - updated

- prepare_data(raw_inputs, cfg): builds processed dict used by GA and reporting.
- Integrates optimized SIG_Dict_creation_4 to write lvl3tolvl5_dict_v4.pkl (atomic).
- Returns the same processed dict shape used by ga_engine and reporting.

Expectations:
- raw_inputs should contain:
    - dat (shipto-level DataFrame produced by fetch_w1_sales_data)
    - dat_zip (sales rep-level DataFrame produced by build_dat_zip_from_snapshot)
    - dat_full (optional)
    - dat_2 (optional)
    - SIG_names (optional)
"""

from typing import Dict, Any, Optional
import os
import pickle
import pandas as pd
import numpy as np
from datetime import datetime
from logger_utils import log_execution, init_log
from config import get_default_config
from scipy.spatial import ConvexHull, Delaunay
from scipy.spatial.distance import pdist, squareform
from typing import Sequence, Tuple, Any, List

_cfg = get_default_config()
init_log(_cfg.LOG_FILE)


def round_list_values(float_list):
    return [int(x) for x in float_list]

def haversine_distance_array(coord1: Sequence[float], coord2: Sequence[float]) -> float:
    from math import radians, sin, cos, sqrt, asin
    lat1, lon1 = coord1
    lat2, lon2 = coord2
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*(sin(dlon/2)**2)
    c = 2 * asin(sqrt(a))
    return 3958.8 * c

def _atomic_write_pickle(obj: Any, path: str):
    """Write pickle atomically (safe for production)."""
    import tempfile
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with tempfile.NamedTemporaryFile(delete=False, dir=os.path.dirname(path) or ".") as tmp:
        pickle.dump(obj, tmp)
        tmp_name = tmp.name
    os.replace(tmp_name, path)


@log_execution("preprocessing", "prepare_data", "Build processed dict and lvl3->lvl5 pickle", log_path=_cfg.LOG_FILE)
def prepare_data(raw_inputs: Dict[str, pd.DataFrame],
                 cfg = _cfg,
                 create_lvl3lvl5_pickle: bool = True,
                 pickle_out_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Convert raw_inputs into processed dict for GA, and write lvl3tolvl5_dict_v4.pkl if requested.
    """
    processed: Dict[str, Any] = {}

    dat = raw_inputs.get("ship_to_raw")
    dat_zip = raw_inputs.get("sales_rep_raw")
    SIG_names = raw_inputs.get("SIG_names", pd.DataFrame())
    
    dat_zip = dat_zip.dropna(subset=['lat'])

    dat_zip = dat_zip.reset_index(drop=True)
    
    # Define the desired new column order in a list
    new_order = ["Ship_To_Customer", "SIG", "Total_Sales", "Level3_Employee", "Level4_Employee", "Level5_Employee", "Ship_To_City", "Ship_To_Customer_Name", "Ship_To_State", "Ship_To_Street_Address", "Entpr_ID_3", "Entpr_ID_4", "Entpr_ID_5", "Ship_To_Postal_Code", "lat", "lon"]

    # Rearrange the columns
    dat = dat[new_order]
    
    dat.columns =['shipto','SIG','sales','lvl3_name','lvl4_name','lvl5_name','city','ship_to_customer_name','state','address','lvl3','lvl4','lvl5','zip','lat','lon']

    # Basic validation
    if dat is None:
        raise ValueError("prepare_data requires raw_inputs['dat']")
    if dat_zip is None:
        raise ValueError("prepare_data requires raw_inputs['dat_zip']")
        
    # Get the unique values from the column in df2
    # Converting to a set can be more efficient for large data
    available_ids = set(dat['lvl5'].unique())

    # Filter df1 to keep only rows where 'ID' is in 'available_ids'
    SIG_names = SIG_names[SIG_names['Entpr_ID_5'].isin(available_ids)]
    
    SIG_names = SIG_names.reset_index(drop=True)
    
    SIG_names = SIG_names.sort_values(by='Entpr_ID_5')
    
    SIG_names['lvl3_lvl_5_SIG'] = SIG_names['SIG'] + "_" + SIG_names['Entpr_ID_3'] +  "_" + SIG_names['Entpr_ID_5']
    
    SIG_names["SIG_lvl5_int"] = (SIG_names.lvl3_lvl_5_SIG.astype('category')).cat.codes

    dat_zip = pd.merge(dat_zip,SIG_names,left_on="Entpr_ID_5",right_on="Entpr_ID_5",how="left")
    
    dat_zip_2 = dat_zip[["Entpr_ID_3", "Entpr_ID_4", "Entpr_ID_5","SIG","SIG_lvl5_int","lvl3_lvl_5_SIG"]]
    dat_zip_2 = dat_zip_2.drop_duplicates(subset='lvl3_lvl_5_SIG', keep="first")
    dat_zip_2 = dat_zip_2.drop(['lvl3_lvl_5_SIG'], axis =1)
    
    SIG_names = SIG_names.drop(['Entpr_ID_4'], axis =1)
    
    dat_zip = dat_zip.drop(['lvl3_lvl_5_SIG'], axis =1)
    
    dat_zip['SIG_lvl5_int'] = dat_zip['SIG_lvl5_int'].astype('Int64')
    
    n_lvl5_unq = list(pd.unique(dat_zip.SIG_lvl5_int))
    
    n_lvl5 = len(n_lvl5_unq)
    
    dat['lvl3_lvl_5_SIG'] = dat['SIG'] + "_" + dat['lvl3'] +  "_" +dat['lvl5']
    
    dat = pd.merge(dat,SIG_names,left_on="lvl3_lvl_5_SIG",right_on="lvl3_lvl_5_SIG",how="left")
    
    dat = dat.reset_index(drop=True)
    
    dat = dat.rename(columns={'SIG_x': 'SIG'})
    
    dat = dat.drop_duplicates(subset=['shipto'], keep='first')
    
    dat = dat.drop(['Entpr_ID_3'], axis =1)
    dat = dat.drop(['Entpr_ID_5'], axis =1)
    
    dat = dat.drop(['SIG_y'], axis =1)
    
    dat["shipto_int"] = (dat.shipto.astype('category')).cat.codes
    
    dat_3 = dat[["lvl3", "lvl4", "lvl5","SIG","SIG_lvl5_int","lvl3_lvl_5_SIG"]]
    dat_3 = dat_3.drop_duplicates(subset='lvl3_lvl_5_SIG', keep="first")
    dat_3 = dat_3.drop(['lvl3_lvl_5_SIG'], axis =1)
    dat_3 = dat_3.rename(columns={'lvl3':'Entpr_ID_3','lvl4':'Entpr_ID_4','lvl5':'Entpr_ID_5'})
    
    dat = dat.rename(columns={'SIG_lvl5_int': 'lvl5_int'})
    dat['lvl5_int'] = dat['lvl5_int'].astype('Int64')
    
    dat = dat.drop(['lvl3_lvl_5_SIG'], axis =1)
    
    dat_2 = dat[~dat['lvl5_int'].isin(n_lvl5_unq)]

    dat_2 = dat_2.reset_index(drop=True)

    dat = dat[dat['lvl5_int'].isin(n_lvl5_unq)]

    dat = dat.dropna(subset=['lat'])

    dat = dat.reset_index(drop=True)
    
    dat = dat.sample(frac=1).reset_index(drop=True)
    
    column_array = dat['lvl5_int'].to_numpy()
    
    # Work on copies
    dat = dat.copy()
    dat_zip = dat_zip.copy()

    # Ensure Entpr_ID_5 exists
    if "lvl5" not in dat.columns:
        dat["lvl5"] = pd.NA
    if "Entpr_ID_5" not in dat_zip.columns:
        dat_zip["Entpr_ID_5"] = pd.NA

    # Ensure Sales numeric
    if "sales" in dat.columns:
        dat["sales"] = pd.to_numeric(dat["sales"], errors="coerce").fillna(0.0)
    else:
        dat["sales"] = 0.0

    # Ensure lat/lon numeric in dat_zip
    for col in ["lat", "lon"]:
        if col in dat_zip.columns:
            dat_zip[col] = pd.to_numeric(dat_zip[col], errors="coerce")
        else:
            dat_zip[col] = np.nan

    # Rounded sales
    dat['sales'] = dat['sales'].apply(lambda x: round(x, 2))
    
    region_dists_a = []
    for lvl5 in n_lvl5_unq:
        try:
            rep_row = dat_zip.loc[dat_zip["SIG_lvl5_int"] == lvl5]
            if rep_row.empty:
                region_dists_a.append(0.0)
                continue
            rep_coord = tuple(rep_row[["lat", "lon"]].to_numpy()[0])
            shipto_coords = dat.loc[np.where(column_array == lvl5)[0], ["lat", "lon"]].to_numpy()
            if shipto_coords.shape[0] == 0:
                region_dists_a.append(0.0)
                continue
            s = 0.0
            # dist_list = []
            for sc in shipto_coords:
                dist = haversine_distance_array(tuple(sc), rep_coord)
                # dist_list.append(dist)
                s += dist
            region_dists_a.append(s)           
        except Exception:
            logger.exception("Error computing region dist for lvl5=%s", lvl5)
            region_dists_a.append(0.0)
            
    rounded_list = round_list_values(region_dists_a)
    rounded_list = np.array(rounded_list)
    print("rounded_list",rounded_list)
    
    region_dists_avg = []
    for lvl5 in n_lvl5_unq:
        try:
            sum_dist_avg = 0.0
            rep_row = dat_zip.loc[dat_zip["SIG_lvl5_int"] == lvl5]
            if rep_row.empty:
                region_dists_avg.append(0.0)
                continue
            rep_coord = tuple(rep_row[["lat", "lon"]].to_numpy()[0])
            shipto_coords = dat.loc[np.where(column_array == lvl5)[0], ["lat", "lon"]].to_numpy()
            if shipto_coords.shape[0] == 0:
                region_dists_avg.append(0.0)
                continue
            dist_list = []
            for sc in shipto_coords:
                dist = haversine_distance_array(tuple(sc), rep_coord)
                dist_list.append(dist)
            sum_dist_avg = np.mean(dist_list)
            region_dists_avg.append(sum_dist_avg) 
        except Exception:
            logger.exception("Error computing region dist for lvl5=%s", lvl5)
            region_dists_avg.append(0.0)
            sum_dist_avg = 0.0
            
    rounded_list_avg = round_list_values(region_dists_avg)
    rounded_list_avg = [x * 100 for x in rounded_list_avg]
    rounded_list_avg = np.array(rounded_list_avg)
    print("rounded_list_avg",rounded_list_avg)
    rounded_list_avg_10 = [(x * 10)/100 for x in rounded_list_avg]
    rounded_list_avg_10 = round_list_values(rounded_list_avg_10)
    print("rounded_list_avg_10",rounded_list_avg_10)
    
    actual_array = np.array(dat["lvl5_int"])
    dat_lvl5 = dat[["lvl5","lvl5_int"]]
    dat_lvl5 = dat_lvl5.drop_duplicates(subset='lvl5_int', keep="first")

    # Build processed dict
    processed["dat"] = dat
    processed["dat_zip"] = dat_zip
    processed["actual_array"] = actual_array
    processed["dat_lvl5"] = dat_lvl5
    processed["dat_2"] = dat_2
    processed["SIG_names"] = SIG_names
    processed["rounded_list"] = rounded_list
    processed["rounded_list_avg"] = rounded_list_avg
    processed["rounded_list_avg_10"] = rounded_list_avg_10
    processed["n_lvl5_unq"] = n_lvl5_unq
    processed["timestamp"] = datetime.utcnow().isoformat()
    processed["column_array"] = column_array

    # -----------------------------
    # Create lvl3 -> lvl5 mapping pickle
    # -----------------------------
    if create_lvl3lvl5_pickle:
        # Determine mapping source
        # Prefer 'lvl3_name' present in dat; else use SIG_names Entpr_ID_3; else dat_zip.SIG as a fallback
        SIG_names_3 = pd.concat([dat_3,dat_zip_2], ignore_index=True)
        lvl3tolvl5 = SIG_names_3.groupby(['SIG','Entpr_ID_3']).apply(lambda x: x[['Entpr_ID_5','SIG_lvl5_int']].to_dict('records')
        ).reset_index(name='rows_group')

        # Write as pickle atomically
        out_pkl = pickle_out_path or getattr(cfg, "SIG_PICKLE", os.path.join(cfg.LOCAL_DATA_DIR, "lvl3tolvl5_dict_v4.pkl"))
        try:
            _atomic_write_pickle(lvl3tolvl5, out_pkl)
            processed["lvl3tolvl5_dict_v4_path"] = out_pkl
            processed["lvl3tolvl5_dict_v4"] = lvl3tolvl5
        except Exception:
            processed["lvl3tolvl5_dict_v4_path"] = None
            processed["lvl3tolvl5_dict_v4"] = {}

    return processed
