"""
fitness.py

Encapsulated fitness function. The main function is logged for timing and
errors. Replace TODO blocks with domain-specific mismatch logic if needed.
"""

from typing import Sequence, Tuple, Any, List
import numpy as np
import pandas as pd
import logging
from logger_utils import log_execution, init_log
from config import get_default_config

logger = logging.getLogger(__name__)
_cfg = get_default_config()
init_log(_cfg.LOG_FILE)

WEIGHT_VP_MISMATCH = 1000000
WEIGHT_SIG_MISMATCH = 10000000

def round_list_values(float_list):
    return [int(x) for x in float_list]

def find_outliers_std_dev(data_list, num_std_dev=2):
    """
    Finds outliers in a list that are more than a specified number of 
    standard deviations from the mean.

    Args:
        data_list (list): The input list of numerical data.
        num_std_dev (int or float): The number of standard deviations 
                                     to use as the outlier threshold.

    Returns:
        list: A list containing the identified outliers.
    """
    if not data_list:
        return []

    data_array = np.array(data_list)
    mean = np.mean(data_array)
    std_dev = np.std(data_array)

    lower_bound = mean - (num_std_dev * std_dev)
    upper_bound = mean + (num_std_dev * std_dev)

    outliers = [x for x in data_list if x < lower_bound or x > upper_bound]
    return outliers

def compare_lists(list1, list2):
    if len(list1) != len(list2):
        return []

    differences = []
    for i in range(len(list1)):
        differences.append(list1[i] - list2[i])
    return differences

def count_greater_than(data_list,rounded_list_avg_10,avg_diff_curr_prop,threshold):
    count = 0
    for i,j,k in zip(data_list,rounded_list_avg_10,avg_diff_curr_prop):
        if i > threshold:
            count += 1
        # elif i < threshold and k<j:
        #     count += 1
    return count

def haversine_distance_array(coord1: Sequence[float], coord2: Sequence[float]) -> float:
    from math import radians, sin, cos, sqrt, asin
    lat1, lon1 = coord1
    lat2, lon2 = coord2
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*(sin(dlon/2)**2)
    c = 2 * asin(sqrt(a))
    return 3958.8 * c

@log_execution("fitness", "fitness_function", "Compute fitness metrics (std, distance, mismatch, total_error)", log_path=_cfg.LOG_FILE)
def fitness_function(candidate_array: Sequence[int], processed: dict) -> Tuple[float, float, float, float, List[float]]:
    dat = processed["dat"]
    dat_zip = processed["dat_zip"]
    dat_lvl5 = processed["dat_lvl5"]
    actual_array = processed["actual_array"]
    n_lvl5_unq = processed["n_lvl5_unq"]
    rounded_list = processed["rounded_list"]
    rounded_list_avg = processed["rounded_list_avg"]
    rounded_list_avg_10 = processed["rounded_list_avg_10"]
    column_array = processed["column_array"]


    arr = np.asarray(candidate_array)
    if arr.shape[0] != dat.shape[0]:
        raise ValueError("Candidate length does not match number of shiptos.")

    # Revenue per predicted lvl5
    dat_fit = pd.DataFrame({'sales': dat['sales'], 'lvl5_int': arr})
    region_revs = dat_fit.groupby('lvl5_int')['sales'].sum()

    actuals_df = pd.DataFrame({"actual": actual_array})
    preds_df = pd.DataFrame({"pred": arr})
    changed_mask = preds_df['pred'].notna() & (preds_df['pred'] != actuals_df['actual'])

    # TODO: compute real VP and SIG mismatch counts by joining with dat/dat_lvl5
    # vp_mismatch_count = 0
    # sig_mismatch_count = 0
    # scores_vp_rg = vp_mismatch_count * WEIGHT_VP_MISMATCH
    # scores_sig_rg = sig_mismatch_count * WEIGHT_SIG_MISMATCH
    
    outliers_total = 0
    region_dists = []
    for lvl5 in n_lvl5_unq:
        try:
            rep_row = dat_zip.loc[dat_zip["SIG_lvl5_int"] == lvl5]
            if rep_row.empty:
                region_dists.append(0.0)
                continue
            rep_coord = tuple(rep_row[["lat", "lon"]].to_numpy()[0])
            shipto_coords = dat.loc[np.where(arr == lvl5)[0], ["lat", "lon"]].to_numpy()
            if shipto_coords.shape[0] == 0:
                region_dists.append(0.0)
                continue
            s = 0.0
            dist_list = []
            for sc in shipto_coords:
                dist = haversine_distance_array(tuple(sc), rep_coord)
                dist_list.append(dist)
                s += dist
            outliers = find_outliers_std_dev(dist_list, num_std_dev=3)
            outliers_total += len(outliers)
            region_dists.append(s)            
        except Exception:
            logger.exception("Error computing region dist for lvl5=%s", lvl5)
            region_dists.append(0.0)
            outliers_total = 0
            

    region_dists_avg_2 = []
    for lvl5 in n_lvl5_unq:
        try:
            sum_dist_avg = 0.0
            rep_row = dat_zip.loc[dat_zip["SIG_lvl5_int"] == lvl5]
            if rep_row.empty:
                region_dists_avg_2.append(0.0)
                continue
            rep_coord = tuple(rep_row[["lat", "lon"]].to_numpy()[0])
            shipto_coords = dat.loc[np.where(column_array == lvl5)[0], ["lat", "lon"]].to_numpy()
            if shipto_coords.shape[0] == 0:
                region_dists_avg_2.append(0.0)
                continue
            dist_list = []
            for sc in shipto_coords:
                dist = haversine_distance_array(tuple(sc), rep_coord)
                dist_list.append(dist)
            sum_dist_avg = np.mean(dist_list)
            region_dists_avg_2.append(sum_dist_avg) 
        except Exception:
            logger.exception("Error computing region dist for lvl5=%s", lvl5)
            region_dists_avg_2.append(0.0)
            sum_dist_avg = 0.0  
    
    rounded_list_2 = round_list_values(region_dists)
    rounded_list_2 = np.array(rounded_list_2)
    print("rounded_list_2",rounded_list_2)
    rounded_list_avg_2 = round_list_values(region_dists_avg_2)
    rounded_list_avg_2 = [x * 100 for x in rounded_list_avg_2]
    rounded_list_avg_2 = np.array(rounded_list_avg_2)
    print("rounded_list_avg_2",rounded_list_avg_2)
    
    avg_diff_curr_prop = compare_lists(rounded_list_avg,rounded_list_avg_2)
    greater_elements = rounded_list_2[rounded_list_2 > rounded_list]
    f_list = compare_lists(rounded_list_2,rounded_list)
    result = count_greater_than(f_list,rounded_list_avg_10,avg_diff_curr_prop,0)
    print("f_list",f_list)
    print("rounded_list_avg_10",rounded_list_avg_10)
    print("avg_diff_curr_prop",avg_diff_curr_prop)
    summaf = result*1000000
    summaf2 = outliers_total*1000000
            
    mean_distance_term = float(np.mean(region_dists))*10 if len(region_dists) > 0 else 0.0
    std_revenue_term = (float(np.std(list(region_revs.fillna(0.0)))))/1000 if len(region_revs) > 0 else 0.0
    total_error = -(mean_distance_term + std_revenue_term + summaf)
    mismatch_pct = float(changed_mask.sum()) / float(len(arr)) if len(arr) else 0.0
    print("mean_distance_term",mean_distance_term)
    print("std_revenue_term",std_revenue_term)
    print("mismatch_pct",mismatch_pct)
    print("summaf",summaf)
    print("summaf2",summaf2)
    print("total_error",total_error)

    return (std_revenue_term, mean_distance_term, mismatch_pct, total_error, region_dists)
