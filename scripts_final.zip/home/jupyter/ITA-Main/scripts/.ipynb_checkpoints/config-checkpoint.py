"""
config.py

Production-ready configuration loader.
Single source of truth for all pipeline parameters.
"""

import os
import yaml
from dataclasses import dataclass
from typing import Optional
from logger_utils import init_log

DEFAULT_CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.yaml")


@dataclass
class GAConfig:
    # Core
    PROJECT: str
    USE_BIGQUERY: bool

    # Paths
    LOCAL_DATA_DIR: str
    OUTPUT_DIR: str
    GCS_BUCKET: str
    CHECKPOINT_DIR: str

    # Logging
    LOG_FILE: str
    LOG_LEVEL: str

    # Output artifacts
    DAT_CSV: str
    SALES_REP_DATA_V2: str
    SIG_NAMES_CSV: str
    SIG_PICKLE: str

    # GA parameters
    POPULATION_SIZE: int
    MAX_GENERATIONS: int
    ELITE_SIZE: int
    MUTATION_PROBABILITY: float
    CROSSOVER_PROBABILITY: float
    CHECKPOINT_FREQ: int
    SEED: int
    PARALLEL_EVAL: bool

    # Geo
    GEO_ENABLED: bool
    GEO_COUNTRY: str
    GEO_LOOKUP_FILE: str
    GEO_LOOKUP_DIR: str

    @property
    def GEO_LOOKUP_PATH(self) -> str:
        return os.path.normpath(
            os.path.join(self.GEO_LOOKUP_DIR, self.GEO_LOOKUP_FILE)
        )


def _load_yaml(path: str) -> dict:
    if not os.path.exists(path):
        raise FileNotFoundError(f"config.yaml not found at {path}")
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def get_default_config(path: Optional[str] = None) -> GAConfig:
    cfg_path = path or os.getenv("CONFIG_YAML", DEFAULT_CONFIG_PATH)
    raw = _load_yaml(cfg_path)

    cfg = GAConfig(
        PROJECT=raw["PROJECT"],
        USE_BIGQUERY=bool(raw["USE_BIGQUERY"]),

        LOCAL_DATA_DIR=raw["LOCAL_DATA_DIR"],
        OUTPUT_DIR=raw["OUTPUT_DIR"],
        GCS_BUCKET=raw["GCS_BUCKET"],
        CHECKPOINT_DIR=raw["CHECKPOINT_DIR"],

        LOG_FILE=raw["LOG_FILE"],
        LOG_LEVEL=raw["LOG_LEVEL"],

        DAT_CSV=raw["DAT_CSV"],
        SALES_REP_DATA_V2=raw["SALES_REP_DATA_V2"],
        SIG_NAMES_CSV=raw["SIG_NAMES_CSV"],
        SIG_PICKLE=raw["SIG_PICKLE"],

        POPULATION_SIZE=int(raw["POPULATION_SIZE"]),
        MAX_GENERATIONS=int(raw["MAX_GENERATIONS"]),
        ELITE_SIZE=int(raw["ELITE_SIZE"]),
        MUTATION_PROBABILITY=float(raw["MUTATION_PROBABILITY"]),
        CROSSOVER_PROBABILITY=float(raw["CROSSOVER_PROBABILITY"]),
        CHECKPOINT_FREQ=int(raw["CHECKPOINT_FREQ"]),
        SEED=int(raw["SEED"]),
        PARALLEL_EVAL=bool(raw["PARALLEL_EVAL"]),

        GEO_ENABLED=bool(raw["GEO_ENABLED"]),
        GEO_COUNTRY=raw["GEO_COUNTRY"],
        GEO_LOOKUP_FILE=raw["GEO_LOOKUP_FILE"],
        GEO_LOOKUP_DIR=raw["GEO_LOOKUP_DIR"],
    )

    init_log(cfg.LOG_FILE)
    return cfg
