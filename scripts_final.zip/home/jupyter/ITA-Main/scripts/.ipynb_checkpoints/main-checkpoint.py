"""
main.py

Top-level runner. The heavy steps are logged via logger_utils.
"""

import logging
import os
from config import get_default_config
from data_io import load_input_data, save_checkpoint
from preprocessing import prepare_data
import fitness as fitness_mod
from ga_engine import GAEngine, Individual
from reporting import build_final_outputs, write_outputs
from logger_utils import log_execution, init_log

cfg = get_default_config()
init_log(cfg.LOG_FILE)
logging.basicConfig(level=getattr(logging, cfg.LOG_LEVEL.upper(), logging.INFO))
logger = logging.getLogger(__name__)

@log_execution("main", "main", "Full pipeline: load, preprocess, run GA, report & persist", log_path=cfg.LOG_FILE)
def main():
    logger.info("Starting Intelligent Territory Alignment runner")
    raw = load_input_data(cfg, limit=None)
    processed = prepare_data(raw)
    data = processed["dat"]
    dat_zip = processed["dat_zip"]
    print("Data da", data.columns)
    # data_zip = raw.get("sales_rep_raw")
    print("data_zip da", dat_zip.columns)
    SIG_names = processed["SIG_names"]
    print("SIG_names da", SIG_names.columns)
    Individual.set_fitness_function(fitness_mod.fitness_function)
    engine = GAEngine(cfg, processed)
    engine.initialize_population()
    best_ind, stats = engine.run()
    os.makedirs(cfg.CHECKPOINT_DIR, exist_ok=True)
    save_checkpoint(engine.population, os.path.join(cfg.CHECKPOINT_DIR, "final_population.pkl"))
    save_checkpoint(best_ind, os.path.join(cfg.CHECKPOINT_DIR, "best_individual.pkl"))
    outputs = build_final_outputs(best_ind, processed, raw)
    write_outputs(outputs, cfg.OUTPUT_DIR)
    logger.info("GA completed. Best fitness: %s", best_ind.fitness[3])
    return best_ind, stats

if __name__ == "__main__":
    main()
