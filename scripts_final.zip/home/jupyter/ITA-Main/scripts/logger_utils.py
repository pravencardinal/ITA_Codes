"""
logger_utils.py

Provides:
 - init_log(file_path): create header row if not exists
 - log_execution(module_name, func_name, func_detail): decorator that
   logs start/end/duration/status/error for the decorated function into log.txt

Log format columns (pipe-separated):
Module Name | Function Name | Function Detail | Start Time | End Time | Duration | Status | Error

Columns use fixed widths to keep the file aligned and human readable.

Usage:
    from logger_utils import log_execution, init_log
    init_log("path/to/log.txt")
    @log_execution("Module", "function_name", "short description")
    def heavy(...): ...
"""

import os
import time
from functools import wraps
from datetime import datetime
import threading

# Column widths (characters) used for pretty alignment
_COL_WIDTHS = {
    "module": 20,
    "func": 30,
    "detail": 40,
    "start": 20,
    "end": 20,
    "duration": 12,
    "status": 12,
    "error": 60
}

_lock = threading.Lock()

def _format_cell(text: str, width: int) -> str:
    """Pad or truncate to fit width; replace newlines with spaces."""
    if text is None:
        text = ""
    text = str(text).replace("\n", " ").strip()
    if len(text) > width:
        return text[: width - 3] + "..."
    return text.ljust(width)

def _compose_row(module, func, detail, start, end, duration, status, error) -> str:
    parts = [
        _format_cell(module, _COL_WIDTHS["module"]),
        _format_cell(func, _COL_WIDTHS["func"]),
        _format_cell(detail, _COL_WIDTHS["detail"]),
        _format_cell(start, _COL_WIDTHS["start"]),
        _format_cell(end, _COL_WIDTHS["end"]),
        _format_cell(duration, _COL_WIDTHS["duration"]),
        _format_cell(status, _COL_WIDTHS["status"]),
        _format_cell(error, _COL_WIDTHS["error"]),
    ]
    return " | ".join(parts) + "\n"

def init_log(path: str):
    """
    Create log file with header if not exists.
    Safe to call multiple times.
    """
    header = _compose_row(
        "Module Name", "Function Name", "Function Detail",
        "Start Time", "End Time", "Duration", "Status", "Error"
    )
    # If file doesn't exist or is empty, write header
    dirpath = os.path.dirname(path)
    if dirpath and not os.path.exists(dirpath):
        os.makedirs(dirpath, exist_ok=True)
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        with open(path, "w", encoding="utf-8") as f:
            f.write(header)

def _write_log(path: str, row: str):
    """Thread-safe append of one row to file."""
    with _lock:
        with open(path, "a", encoding="utf-8") as f:
            f.write(row)

def log_execution(module_name: str, func_name: str, func_detail: str, log_path: str = "log.txt"):
    """
    Decorator to log execution. Example:
      @log_execution("ga_engine", "run", "Run GA loop", log_path="output/log.txt")
      def run(...): ...
    """
    # Ensure header exists
    init_log(log_path)

    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            start_ts = datetime.utcnow()
            start_str = start_ts.strftime("%Y-%m-%d %H:%M:%S")
            status = "Successful"
            err_text = "No Error"
            try:
                result = fn(*args, **kwargs)
                return result
            except Exception as e:
                status = "Not Successful"
                err_text = f"{type(e).__name__}: {e}"
                raise
            finally:
                end_ts = datetime.utcnow()
                end_str = end_ts.strftime("%Y-%m-%d %H:%M:%S")
                dur = end_ts - start_ts
                # format duration as H:MM:SS.mmm
                total_seconds = dur.total_seconds()
                hours = int(total_seconds // 3600)
                mins = int((total_seconds % 3600) // 60)
                secs = int(total_seconds % 60)
                millis = int((total_seconds - int(total_seconds)) * 1000)
                dur_str = f"{hours}:{mins:02d}:{secs:02d}.{millis:03d}"
                row = _compose_row(module_name, func_name, func_detail, start_str, end_str, dur_str, status, err_text)
                _write_log(log_path, row)
        return wrapper
    return decorator
