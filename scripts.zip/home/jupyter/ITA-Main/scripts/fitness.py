"""
fitness.py

Encapsulated fitness function. The main function is logged for timing and
errors. Replace TODO blocks with domain-specific mismatch logic if needed.
"""

from typing import Sequence, Tuple, Any, List
import numpy as np
import pandas as pd
import logging
from logger_utils import log_execution, init_log
from config import get_default_config

logger = logging.getLogger(__name__)
_cfg = get_default_config()
init_log(_cfg.LOG_FILE)

WEIGHT_VP_MISMATCH = 1_000_000
WEIGHT_SIG_MISMATCH = 10_000_000

def haversine_distance_array(coord1: Sequence[float], coord2: Sequence[float]) -> float:
    from math import radians, sin, cos, sqrt, asin
    lat1, lon1 = coord1
    lat2, lon2 = coord2
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*(sin(dlon/2)**2)
    c = 2 * asin(sqrt(a))
    return 3958.8 * c

@log_execution("fitness", "fitness_function", "Compute fitness metrics (std, distance, mismatch, total_error)", log_path=_cfg.LOG_FILE)
def fitness_function(candidate_array: Sequence[int], processed: dict) -> Tuple[float, float, float, float, List[float]]:
    dat = processed["dat"]
    dat_zip = processed["dat_zip"]
    dat_lvl5 = processed["dat_lvl5"]
    actual_array = processed["actual_array"]
    n_lvl5_unq = processed["n_lvl5_unq"]
    rounded_list = processed["rounded_list"]

    arr = np.asarray(candidate_array)
    if arr.shape[0] != dat.shape[0]:
        raise ValueError("Candidate length does not match number of shiptos.")

    # Revenue per predicted lvl5
    dat_fit = pd.DataFrame({'sales': dat['sales'], 'lvl5_int': arr})
    region_revs = dat_fit.groupby('lvl5_int')['sales'].sum()

    actuals_df = pd.DataFrame({"actual": actual_array})
    preds_df = pd.DataFrame({"pred": arr})
    changed_mask = preds_df['pred'].notna() & (preds_df['pred'] != actuals_df['actual'])

    # TODO: compute real VP and SIG mismatch counts by joining with dat/dat_lvl5
    vp_mismatch_count = 0
    sig_mismatch_count = 0
    scores_vp_rg = vp_mismatch_count * WEIGHT_VP_MISMATCH
    scores_sig_rg = sig_mismatch_count * WEIGHT_SIG_MISMATCH

    region_dists = []
    for lvl5 in n_lvl5_unq:
        try:
            rep_row = dat_zip.loc[dat_zip["SIG_lvl5_int"] == lvl5]
            if rep_row.empty:
                region_dists.append(0.0)
                continue
            rep_coord = tuple(rep_row[["lat", "lon"]].to_numpy()[0])
            shipto_coords = dat.loc[arr == lvl5, ["lat", "lon"]].to_numpy()
            if shipto_coords.shape[0] == 0:
                region_dists.append(0.0)
                continue
            s = 0.0
            for sc in shipto_coords:
                s += haversine_distance_array(tuple(sc), rep_coord)
            region_dists.append(s)
        except Exception:
            logger.exception("Error computing region dist for lvl5=%s", lvl5)
            region_dists.append(0.0)

    mean_distance_term = float(np.mean(region_dists)) if len(region_dists) > 0 else 0.0
    std_revenue_term = float(np.std(list(region_revs.fillna(0.0)))) if len(region_revs) > 0 else 0.0
    total_error = -(scores_vp_rg + scores_sig_rg + mean_distance_term + std_revenue_term)
    mismatch_pct = float(changed_mask.sum()) / float(len(arr)) if len(arr) else 0.0

    return (std_revenue_term, mean_distance_term, mismatch_pct, total_error, region_dists)
