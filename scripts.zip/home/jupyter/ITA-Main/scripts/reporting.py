"""
reporting_v16.py (fixed SIG KeyError, robust merges)

This file preserves your original reporting flow while keeping the
vectorized and modular improvements. It ensures `SIG` is produced
by the merge with unique_lvl5 (as in your original Get_Data script).
"""

from typing import Dict, Any, List
import pandas as pd
import numpy as np
import logging
import os
from logger_utils import log_execution, init_log
from config import get_default_config
from data_io import save_predictions_csv

logger = logging.getLogger(__name__)
_cfg = get_default_config()
init_log(_cfg.LOG_FILE)


def vectorized_haversine(lat1: np.ndarray, lon1: np.ndarray, lat2: np.ndarray, lon2: np.ndarray) -> np.ndarray:
    """
    Vectorized haversine distance in miles between arrays of coordinates.
    Returns np.nan where inputs are missing.
    """
    lat1 = np.asarray(lat1, dtype=float)
    lon1 = np.asarray(lon1, dtype=float)
    lat2 = np.asarray(lat2, dtype=float)
    lon2 = np.asarray(lon2, dtype=float)

    mask = np.isnan(lat1) | np.isnan(lon1) | np.isnan(lat2) | np.isnan(lon2)
    lat1r = np.radians(lat1)
    lon1r = np.radians(lon1)
    lat2r = np.radians(lat2)
    lon2r = np.radians(lon2)

    dlat = lat2r - lat1r
    dlon = lon2r - lon1r
    a = np.sin(dlat / 2.0) ** 2 + np.cos(lat1r) * np.cos(lat2r) * (np.sin(dlon / 2.0) ** 2)
    c = 2 * np.arcsin(np.sqrt(np.clip(a, 0.0, 1.0)))
    miles = 3958.8 * c
    miles[mask] = np.nan
    return miles


def _ensure_str_cols(df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    """Ensure listed columns exist and are string typed (create if missing)."""
    for c in cols:
        if c not in df.columns:
            df[c] = pd.NA
        df[c] = df[c].astype("string")
    return df


def _agg_std_var_by_lvl3(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute Std_Dev and Variance per lvl3 for both current and proposed mappings.
    Mirrors your original loop-based aggregation but uses groupby for clarity.
    """
    out_cols = ["ga_pred_v2_lvl3_name", "Std_Dev_Current", "Variance_Current", "Std_Dev_Proposed", "Variance_Proposed"]

    # If key proposed columns missing, return empty df with schema
    if "ga_pred_v2_lvl3_name" not in df.columns or "ga_pred_v2_lvl5_name" not in df.columns or "ga_pred_v2_sales" not in df.columns:
        return pd.DataFrame(columns=out_cols)

    proposed = df.groupby(["ga_pred_v2_lvl3_name", "ga_pred_v2_lvl5_name"])["ga_pred_v2_sales"].sum().reset_index()
    proposed_stats = proposed.groupby("ga_pred_v2_lvl3_name")["ga_pred_v2_sales"].agg(["std", "var"]).reset_index().rename(
        columns={"std": "Std_Dev_Proposed", "var": "Variance_Proposed", "ga_pred_v2_lvl3_name": "ga_pred_v2_lvl3_name"}
    )

    if "finance_team_sales" in df.columns and "finance_team_lvl3_name" in df.columns and "finance_team_lvl5_name" in df.columns:
        curr = df.groupby(["finance_team_lvl3_name", "finance_team_lvl5_name"])["finance_team_sales"].sum().reset_index()
        curr_stats = curr.groupby("finance_team_lvl3_name")["finance_team_sales"].agg(["std", "var"]).reset_index().rename(
            columns={"std": "Std_Dev_Current", "var": "Variance_Current", "finance_team_lvl3_name": "ga_pred_v2_lvl3_name"}
        )
    else:
        curr_stats = pd.DataFrame(columns=["ga_pred_v2_lvl3_name", "Std_Dev_Current", "Variance_Current"])

    merged = pd.merge(curr_stats, proposed_stats, on="ga_pred_v2_lvl3_name", how="outer")
    for c in ["Std_Dev_Current", "Variance_Current", "Std_Dev_Proposed", "Variance_Proposed"]:
        merged[c] = merged.get(c, 0.0).fillna(0.0).astype(float).round(2)
    return merged[out_cols]


@log_execution("reporting", "build_final_outputs", "Build final merged outputs and summary stats for Tableau (fixed SIG)", log_path=_cfg.LOG_FILE)
def build_final_outputs(best_ind, processed: Dict[str, Any], raw_inputs: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
    """
    Returns dict with keys:
      - df_merged, final_data, actuals_ga_pred_v2, std_dev_var_vp, final
    This implementation follows your original merge order so SIG is present as expected.
    """
    dat = processed["dat"].copy()
    dat_zip = processed["dat_zip"].copy()

    # Step A: predicted mapping (must match original logic)
    predicted = pd.DataFrame(np.array(best_ind.gene_list), columns=["predicted"])
    dat_2 = dat.copy()
    dat_2["predicted"] = predicted["predicted"].values
    dat_2 = dat_2[["shipto", "predicted"]]

    # Step B: bring in unique lvl5 mapping including SIG, lvl3, lvl4 names (this produces 'SIG')
    # This matches your original script: unique_lvl5 = dat[["SIG","lvl5","lvl5_name","lvl5_int"]].drop_duplicates(...)
    unique_lvl5_cols = [c for c in ["SIG", "lvl5", "lvl5_name", "lvl5_int"] if c in dat.columns]
    if not unique_lvl5_cols:
        # If dat lacks these, but dat_lvl5 exists in processed, try to use that
        if "dat_lvl5" in processed:
            unique_lvl5 = processed["dat_lvl5"].copy()
        else:
            unique_lvl5 = pd.DataFrame(columns=["SIG", "lvl5", "lvl5_name", "lvl5_int"])
    else:
        unique_lvl5 = dat[["SIG", "lvl5", "lvl5_name", "lvl5_int"]].drop_duplicates(subset="lvl5_int", keep="first")

    df_merged = pd.merge(dat_2, unique_lvl5, left_on="predicted", right_on="lvl5_int", how="left")
    if "lvl5_int" in df_merged.columns:
        df_merged.drop(columns=["lvl5_int"], inplace=True, errors=True)

    # Additional merges to bring lvl4 and lvl3 if those exist (preserve original behaviour)
    if all(c in dat.columns for c in ["lvl4", "lvl4_name", "lvl5_int"]):
        unique_lvl4 = dat[["lvl4", "lvl4_name", "lvl5_int"]].drop_duplicates(subset="lvl5_int", keep="first")
        df_merged = pd.merge(df_merged, unique_lvl4, left_on="predicted", right_on="lvl5_int", how="left").drop(columns=["lvl5_int"], errors=True)

    if all(c in dat.columns for c in ["lvl3", "lvl3_name", "lvl5_int"]):
        unique_lvl3 = dat[["lvl3", "lvl3_name", "lvl5_int"]].drop_duplicates(subset="lvl5_int", keep="first")
        df_merged = pd.merge(df_merged, unique_lvl3, left_on="predicted", right_on="lvl5_int", how="left").drop(columns=["lvl5_int"], errors=True)

    # Now df_merged should have 'SIG' (coming from unique_lvl5). If not, create placeholder
    if "SIG" not in df_merged.columns:
        df_merged["SIG"] = pd.Series([pd.NA] * len(df_merged), dtype="string")
    else:
        df_merged["SIG"] = df_merged["SIG"].astype("string")

    # Ensure shipto is string
    df_merged["shipto"] = df_merged["shipto"].astype("string")
    df_merged["shipto_SIG"] = df_merged["shipto"] + "_" + df_merged["SIG"]

    # Step C: construct dat_final (current alignment) — mirror original transform
    dat_final = dat.copy()
    if "lvl5" in dat_final.columns:
        dat_final = dat_final.rename(columns={"lvl5": "lvl5_current_alignment"})
    for c in ["lvl3", "lvl4", "lvl3_name", "lvl4_name", "lvl5_name"]:
        if c in dat_final.columns:
            dat_final.drop(columns=[c], inplace=True, errors=True)
    dat_final["shipto"] = dat_final["shipto"].astype("string")
    dat_final["SIG"] = dat_final["SIG"].astype("string") if "SIG" in dat_final.columns else pd.Series([pd.NA] * len(dat_final), dtype="string")
    dat_final["shipto_SIG"] = dat_final["shipto"] + "_" + dat_final["SIG"]

    final_data = pd.merge(df_merged, dat_final, left_on="shipto_SIG", right_on="shipto_SIG", how="left")

    # Clean up columns similar to original script
    drop_cols = ["lvl5_int", "shipto_int", "shipto_y", "SIG_y"]
    for c in drop_cols:
        if c in final_data.columns:
            final_data.drop(columns=[c], inplace=True, errors=True)
    rename_map = {"shipto_x": "shipto", "SIG_x": "SIG"}
    final_data.rename(columns=rename_map, inplace=True, errors=True)

    # Step D: actuals harmonization (matching original approach)
    actuals = raw_inputs.get("actuals")
    if actuals is None:
        actuals = dat.copy()
        # rename to finance_team_ prefix like original script did
        actuals.columns = ["finance_team_" + str(col) for col in actuals.columns]
        if "finance_team_shipto" in actuals.columns and "finance_team_SIG" in actuals.columns:
            actuals["finance_team_shipto_SIG"] = actuals["finance_team_shipto"].astype("string") + "_" + actuals["finance_team_SIG"]
    else:
        # consistent prefixing if not already present
        if not any(col.startswith("finance_team_") for col in actuals.columns):
            actuals = actuals.rename(columns={col: "finance_team_" + str(col) for col in actuals.columns})
        if "finance_team_shipto" in actuals.columns and "finance_team_SIG" in actuals.columns:
            actuals["finance_team_shipto_SIG"] = actuals["finance_team_shipto"].astype("string") + "_" + actuals["finance_team_SIG"]

    # Step E: build ga_pred_v2 (prefix columns) — match original naming
    ga_pred_v2 = final_data.copy()
    ga_pred_v2.columns = ["ga_pred_v2_" + str(col) for col in ga_pred_v2.columns]
    # ensure keys for merge exist
    if "ga_pred_v2_shipto" not in ga_pred_v2.columns:
        ga_pred_v2["ga_pred_v2_shipto"] = pd.Series([pd.NA] * len(ga_pred_v2), dtype="string")
    if "ga_pred_v2_SIG" not in ga_pred_v2.columns:
        ga_pred_v2["ga_pred_v2_SIG"] = pd.Series([pd.NA] * len(ga_pred_v2), dtype="string")
    ga_pred_v2["ga_pred_v2_shipto_SIG"] = ga_pred_v2["ga_pred_v2_shipto"].astype("string") + "_" + ga_pred_v2["ga_pred_v2_SIG"].astype("string")

    # Step F: merge actuals and ga_pred_v2 to create comparable rows
    actuals_ga_pred_v2 = pd.merge(actuals, ga_pred_v2, left_on="finance_team_shipto_SIG", right_on="ga_pred_v2_shipto_SIG", how="inner")

    # Step G: merge dat_zip (rep lat/lon) for finance_team_lvl5 and ga_pred_v2_lvl5 (mirrors original)
    if {"Entpr_ID_5", "lat", "lon"}.issubset(dat_zip.columns):
        actuals_ga_pred_v2 = pd.merge(actuals_ga_pred_v2,
                                       dat_zip[["Entpr_ID_5", "lat", "lon"]].rename(columns={"lat": "finance_team_rep_lat", "lon": "finance_team_rep_lon"}),
                                       left_on="finance_team_lvl5", right_on="Entpr_ID_5", how="left")
        actuals_ga_pred_v2.drop(columns=["Entpr_ID_5"], inplace=True, errors=True)

        if "ga_pred_v2_lvl5" in actuals_ga_pred_v2.columns:
            actuals_ga_pred_v2 = pd.merge(actuals_ga_pred_v2,
                                           dat_zip[["Entpr_ID_5", "lat", "lon"]].rename(columns={"lat": "ga_pred_rep_lat", "lon": "ga_pred_rep_lon"}),
                                           left_on="ga_pred_v2_lvl5", right_on="Entpr_ID_5", how="left")
            actuals_ga_pred_v2.drop(columns=["Entpr_ID_5"], inplace=True, errors=True)

    # Step H: compute vectorized distances (use available coords)
    def _coord_exists(df, latc, lonc):
        return latc in df.columns and lonc in df.columns

    # finance team coordinate priority: finance_team_lat/lon (if present) else finance_team_rep_lat/rep_lon
    if _coord_exists(actuals_ga_pred_v2, "finance_team_lat", "finance_team_lon"):
        actuals_ga_pred_v2["coord_ft_lat"] = actuals_ga_pred_v2["finance_team_lat"].astype(float)
        actuals_ga_pred_v2["coord_ft_lon"] = actuals_ga_pred_v2["finance_team_lon"].astype(float)
    elif _coord_exists(actuals_ga_pred_v2, "finance_team_rep_lat", "finance_team_rep_lon"):
        actuals_ga_pred_v2["coord_ft_lat"] = actuals_ga_pred_v2["finance_team_rep_lat"].astype(float)
        actuals_ga_pred_v2["coord_ft_lon"] = actuals_ga_pred_v2["finance_team_rep_lon"].astype(float)
    else:
        actuals_ga_pred_v2["coord_ft_lat"] = np.nan
        actuals_ga_pred_v2["coord_ft_lon"] = np.nan

    # ga_pred coordinate priority: ga_pred_v2_lat/lon else ga_pred_rep_lat/rep_lon
    if _coord_exists(actuals_ga_pred_v2, "ga_pred_v2_lat", "ga_pred_v2_lon"):
        actuals_ga_pred_v2["coord_ga_lat"] = actuals_ga_pred_v2["ga_pred_v2_lat"].astype(float)
        actuals_ga_pred_v2["coord_ga_lon"] = actuals_ga_pred_v2["ga_pred_v2_lon"].astype(float)
    elif _coord_exists(actuals_ga_pred_v2, "ga_pred_rep_lat", "ga_pred_rep_lon"):
        actuals_ga_pred_v2["coord_ga_lat"] = actuals_ga_pred_v2["ga_pred_rep_lat"].astype(float)
        actuals_ga_pred_v2["coord_ga_lon"] = actuals_ga_pred_v2["ga_pred_rep_lon"].astype(float)
    else:
        actuals_ga_pred_v2["coord_ga_lat"] = np.nan
        actuals_ga_pred_v2["coord_ga_lon"] = np.nan

    actuals_ga_pred_v2["dist_btw_finance_team_&_rep"] = vectorized_haversine(
        actuals_ga_pred_v2["coord_ft_lat"].to_numpy(),
        actuals_ga_pred_v2["coord_ft_lon"].to_numpy(),
        actuals_ga_pred_v2["coord_ga_lat"].to_numpy(),
        actuals_ga_pred_v2["coord_ga_lon"].to_numpy()
    )

    # Original code did gaussian-like outlier detection by group (IQR)
    if "finance_team_lvl5" in actuals_ga_pred_v2.columns:
        def _iqr_outliers(series):
            q1 = series.quantile(0.25)
            q3 = series.quantile(0.75)
            iqr = q3 - q1
            lower = q1 - 1.5 * iqr
            upper = q3 + 1.5 * iqr
            return (series < lower) | (series > upper)
        actuals_ga_pred_v2["outlier"] = actuals_ga_pred_v2.groupby("finance_team_lvl5")["dist_btw_finance_team_&_rep"].transform(_iqr_outliers).fillna(False)
    else:
        actuals_ga_pred_v2["outlier"] = False

    # Step I: std/variance per VP (lvl3)
    std_dev_var_vp_df = _agg_std_var_by_lvl3(actuals_ga_pred_v2)

    # Step J: produce final merged frame similar to original 'final'
    final = actuals_ga_pred_v2.merge(
        std_dev_var_vp_df[["ga_pred_v2_lvl3_name", "Std_Dev_Current", "Variance_Current"]],
        left_on="finance_team_lvl3_name", right_on="ga_pred_v2_lvl3_name", how="left"
    )
    if "ga_pred_v2_lvl3_name_y" in final.columns:
        final.drop(columns=["ga_pred_v2_lvl3_name_y"], inplace=True, errors=True)
    final.rename(columns={"ga_pred_v2_lvl3_name_x": "ga_pred_v2_lvl3_name"}, inplace=True, errors=True)

    final = final.merge(std_dev_var_vp_df[["ga_pred_v2_lvl3_name", "Std_Dev_Proposed", "Variance_Proposed"]],
                        on="ga_pred_v2_lvl3_name", how="left")

    # Distance-related fields / flags
    final["dist_btw_finance_team_&_rep"] = final["dist_btw_finance_team_&_rep"].round(2)
    final["dist_btw_ga_pred_&_rep"] = final.get("dist_btw_ga_pred_&_rep", pd.Series([np.nan] * len(final))).round(2)
    final["Dist Diff"] = (final["dist_btw_finance_team_&_rep"] - final["dist_btw_ga_pred_&_rep"]).abs()

    cond_better = final["dist_btw_finance_team_&_rep"] > final["dist_btw_ga_pred_&_rep"]
    cond_same = final["dist_btw_finance_team_&_rep"].fillna(-1) == final["dist_btw_ga_pred_&_rep"].fillna(-2)
    final["GA Perf On Dist"] = np.select([cond_better, cond_same], ["Better", "Same"], default="Worse")

    if "finance_team_lvl5_name" in final.columns and "ga_pred_v2_lvl5" in final.columns:
        final["Checker"] = np.where(final["finance_team_lvl5_name"] == final["ga_pred_v2_lvl5"], "Same", "Diff")
    else:
        final["Checker"] = "Other"

    final["Hierarchy"] = np.where(final.get("finance_team_SIG") == "SCSE", "Distributor SIG", "Product SIG")

    results = {
        "df_merged": df_merged,
        "final_data": final_data,
        "actuals_ga_pred_v2": actuals_ga_pred_v2,
        "std_dev_var_vp": std_dev_var_vp_df,
        "final": final
    }
    return results


@log_execution("reporting", "write_outputs", "Write all output tables to CSV (atomic)", log_path=_cfg.LOG_FILE)
def write_outputs(outputs: Dict[str, pd.DataFrame], out_dir: str):
    """
    Persist outputs to CSV files in out_dir (atomic writes using save_predictions_csv).
    """
    os.makedirs(out_dir, exist_ok=True)
    for name, df in outputs.items():
        if df is None:
            logger.warning("Skipping write for %s because DataFrame is None", name)
            continue
        path = os.path.join(out_dir, f"{name}.csv")
        try:
            save_predictions_csv(df, path)
            logger.info("Wrote %s to %s", name, path)
        except Exception:
            logger.exception("Failed to write %s", name)