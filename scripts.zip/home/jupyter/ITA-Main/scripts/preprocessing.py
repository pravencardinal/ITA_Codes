"""
preprocessing.py - updated

- prepare_data(raw_inputs, cfg): builds processed dict used by GA and reporting.
- Integrates optimized SIG_Dict_creation_4 to write lvl3tolvl5_dict_v4.pkl (atomic).
- Returns the same processed dict shape used by ga_engine and reporting.

Expectations:
- raw_inputs should contain:
    - dat (shipto-level DataFrame produced by fetch_w1_sales_data)
    - dat_zip (sales rep-level DataFrame produced by build_dat_zip_from_snapshot)
    - dat_full (optional)
    - dat_2 (optional)
    - SIG_names (optional)
"""

from typing import Dict, Any, Optional
import os
import pickle
import pandas as pd
import numpy as np
from datetime import datetime
from logger_utils import log_execution, init_log
from config import get_default_config

_cfg = get_default_config()
init_log(_cfg.LOG_FILE)


def _atomic_write_pickle(obj: Any, path: str):
    """Write pickle atomically (safe for production)."""
    import tempfile
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with tempfile.NamedTemporaryFile(delete=False, dir=os.path.dirname(path) or ".") as tmp:
        pickle.dump(obj, tmp)
        tmp_name = tmp.name
    os.replace(tmp_name, path)


@log_execution("preprocessing", "prepare_data", "Build processed dict and lvl3->lvl5 pickle", log_path=_cfg.LOG_FILE)
def prepare_data(raw_inputs: Dict[str, pd.DataFrame],
                 cfg = _cfg,
                 create_lvl3lvl5_pickle: bool = True,
                 pickle_out_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Convert raw_inputs into processed dict for GA, and write lvl3tolvl5_dict_v4.pkl if requested.
    """
    processed: Dict[str, Any] = {}

    dat = raw_inputs.get("ship_to_raw")
    dat_zip = raw_inputs.get("dat_zip")
    dat_full = raw_inputs.get("dat_full", pd.DataFrame())
    dat_2 = raw_inputs.get("dat_2", pd.DataFrame())
    SIG_names = raw_inputs.get("SIG_names", pd.DataFrame())

    # Basic validation
    if dat is None:
        raise ValueError("prepare_data requires raw_inputs['dat']")
    if dat_zip is None:
        raise ValueError("prepare_data requires raw_inputs['dat_zip']")

    # Work on copies
    dat = dat.copy()
    dat_zip = dat_zip.copy()

    # Ensure Entpr_ID_5 exists
    if "Entpr_ID_5" not in dat.columns:
        dat["Entpr_ID_5"] = pd.NA
    if "Entpr_ID_5" not in dat_zip.columns:
        dat_zip["Entpr_ID_5"] = pd.NA

    # Ensure Sales numeric
    if "Sales" in dat.columns:
        dat["Sales"] = pd.to_numeric(dat["Sales"], errors="coerce").fillna(0.0)
    else:
        dat["Sales"] = 0.0

    # Ensure lat/lon numeric in dat_zip
    for col in ["lat", "lon"]:
        if col in dat_zip.columns:
            dat_zip[col] = pd.to_numeric(dat_zip[col], errors="coerce")
        else:
            dat_zip[col] = np.nan

    # Attach lvl5_int to dat using dat_zip.SIG_lvl5_int mapping when available
    if "SIG_lvl5_int" in dat_zip.columns:
        entpr_to_code = dict(zip(dat_zip["Entpr_ID_5"].astype(str), dat_zip["SIG_lvl5_int"].astype(int)))
        dat["lvl5_int"] = dat["Entpr_ID_5"].astype(str).map(entpr_to_code).fillna(-1).astype(int)
    else:
        # fallback to deterministic categorical codes from dat
        unique_entprs = sorted(dat["Entpr_ID_5"].astype(str).unique())
        entpr_code = {e: i for i, e in enumerate(unique_entprs)}
        dat["lvl5_int"] = dat["Entpr_ID_5"].astype(str).map(entpr_code).fillna(-1).astype(int)

    # Rounded list used by GA
    rounded_list = list(dat["Sales"].round(2).tolist())

    # Build processed dict
    processed["dat"] = dat
    processed["dat_zip"] = dat_zip
    processed["dat_full"] = dat_full
    processed["dat_2"] = dat_2
    processed["SIG_names"] = SIG_names
    processed["rounded_list"] = rounded_list
    processed["n_lvl5_unq"] = int(dat["lvl5_int"].max() + 1) if len(dat) > 0 else 0
    processed["timestamp"] = datetime.utcnow().isoformat()

    # -----------------------------
    # Create lvl3 -> lvl5 mapping pickle
    # -----------------------------
    if create_lvl3lvl5_pickle:
        # Determine mapping source
        # Prefer 'lvl3_name' present in dat; else use SIG_names Entpr_ID_3; else dat_zip.SIG as a fallback
        if "lvl3_name" in dat.columns and "Entpr_ID_5" in dat.columns:
            map_df = dat[["lvl3_name", "Entpr_ID_5"]].drop_duplicates().rename(columns={"lvl3_name": "lvl3_name"})
        elif not SIG_names.empty and "Entpr_ID_3" in SIG_names.columns and "Entpr_ID_5" in SIG_names.columns:
            src = SIG_names.copy()
            lvl3_col = "lvl3_name" if "lvl3_name" in src.columns else "Entpr_ID_3"
            map_df = src[[lvl3_col, "Entpr_ID_5"]].rename(columns={lvl3_col: "lvl3_name"}).drop_duplicates()
        else:
            if "SIG" in dat_zip.columns:
                map_df = dat_zip[["SIG", "Entpr_ID_5"]].rename(columns={"SIG": "lvl3_name"}).drop_duplicates()
            else:
                map_df = pd.DataFrame(columns=["lvl3_name", "Entpr_ID_5"])

        # Build level5 name mapping using dat_full (lvl5_name) or dat_zip Level5_Employee
        lvl5_name_map = {}
        if not dat_full.empty and "Entpr_ID_5" in dat_full.columns and "lvl5_name" in dat_full.columns:
            tmp = dat_full[["Entpr_ID_5", "lvl5_name"]].drop_duplicates()
            lvl5_name_map.update(dict(zip(tmp["Entpr_ID_5"].astype(str), tmp["lvl5_name"].astype(str))))
        if "Level5_Employee" in dat_zip.columns:
            tmp2 = dat_zip[["Entpr_ID_5", "Level5_Employee"]].drop_duplicates()
            for k, v in zip(tmp2["Entpr_ID_5"].astype(str), tmp2["Level5_Employee"].astype(str)):
                if k not in lvl5_name_map or not lvl5_name_map[k]:
                    lvl5_name_map[k] = v

        # Build the final dict in deterministic order
        lvl3tolvl5 = {}
        for lvl3, group in map_df.groupby("lvl3_name"):
            entprs = sorted(group["Entpr_ID_5"].astype(str).dropna().unique().tolist())
            lvl5_meta = []
            for ent in entprs:
                sig_idx_series = dat_zip.loc[dat_zip["Entpr_ID_5"].astype(str) == ent, "SIG_lvl5_int"]
                sig_idx = int(sig_idx_series.iloc[0]) if (not sig_idx_series.empty and pd.notna(sig_idx_series.iloc[0])) else None
                meta = {"Entpr_ID_5": ent, "lvl5_name": lvl5_name_map.get(ent, None), "SIG_lvl5_int": sig_idx}
                lvl5_meta.append(meta)
            lvl3tolvl5[str(lvl3)] = {"lvl5_list": entprs, "lvl5_meta": lvl5_meta}

        # Write as pickle atomically
        out_pkl = pickle_out_path or getattr(cfg, "SIG_PICKLE", os.path.join(cfg.LOCAL_DATA_DIR, "lvl3tolvl5_dict_v4.pkl"))
        try:
            _atomic_write_pickle(lvl3tolvl5, out_pkl)
            processed["lvl3tolvl5_dict_v4_path"] = out_pkl
            processed["lvl3tolvl5_dict_v4"] = lvl3tolvl5
        except Exception:
            processed["lvl3tolvl5_dict_v4_path"] = None
            processed["lvl3tolvl5_dict_v4"] = {}

    return processed
