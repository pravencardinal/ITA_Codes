"""
alteryx_replacements.py

Pure transformation layer.
NO SQL.
NO BigQuery calls.
"""

import pandas as pd
import numpy as np
import pgeocode
import os
# os.environ.setdefault("PGEOCODE_DATA_DIR", "/home/jupyter/pgeocode_data")
# nom = pgeocode.Nominatim('US')
from logger_utils import log_execution
from config import get_default_config
from functools import lru_cache

cfg = get_default_config()


@lru_cache(maxsize=1)
def _load_postal_geo_lookup() -> pd.DataFrame:
    """
    Robust loader for postal geo lookup.

    - Works when code is run from ITA-Main/scripts
    - Supports absolute OR project-relative GEO_LOOKUP_DIR
    - Emits precise error details for production debugging
    """

    if not getattr(cfg, "GEO_ENABLED", True):
        return pd.DataFrame(columns=["postal_code", "lat", "lon"])

    # --------------------------------------------------
    # Resolve project root (ITA-Main)
    # --------------------------------------------------
    current_file = os.path.abspath(__file__)
    scripts_dir = os.path.dirname(current_file)
    project_root = os.path.dirname(scripts_dir)

    # --------------------------------------------------
    # Resolve GEO_LOOKUP_DIR
    # --------------------------------------------------
    geo_dir_cfg = cfg.GEO_LOOKUP_DIR.strip()

    if os.path.isabs(geo_dir_cfg):
        resolved_geo_dir = geo_dir_cfg
    else:
        resolved_geo_dir = os.path.join(project_root, geo_dir_cfg)

    resolved_geo_dir = os.path.normpath(resolved_geo_dir)
    geo_file_path = os.path.join(resolved_geo_dir, cfg.GEO_LOOKUP_FILE)

    # --------------------------------------------------
    # Validate existence
    # --------------------------------------------------
    if not os.path.exists(geo_file_path):
        raise FileNotFoundError(
            "\nGeo lookup file not found.\n"
            f"Resolved path : {geo_file_path}\n"
            f"Project root : {project_root}\n"
            f"GEO_LOOKUP_DIR (config): {cfg.GEO_LOOKUP_DIR}\n"
            f"GEO_LOOKUP_FILE (config): {cfg.GEO_LOOKUP_FILE}\n"
            f"Contents of resolved dir ({resolved_geo_dir}): "
            f"{os.listdir(resolved_geo_dir) if os.path.exists(resolved_geo_dir) else 'DIR DOES NOT EXIST'}"
        )

    # --------------------------------------------------
    # Load & validate
    # --------------------------------------------------
    df = pd.read_csv(geo_file_path)

    required_cols = {"postal_code", "lat", "lon"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(
            f"Geo lookup file missing columns: {missing}. "
            f"Found columns: {list(df.columns)}"
        )

    df["postal_code"] = df["postal_code"].astype(str).str.strip()

    return df


# -------------------------------
# Simple pgeocode-based geocoder
# -------------------------------
def _get_lat_lon_from_postal(postal_series: pd.Series) -> pd.DataFrame:
    lookup_df = _load_postal_geo_lookup()

    s = (
        postal_series.astype(str)
        .str.strip()
        .str[:5]
        .replace({"nan": None, "None": None, "": None})
    )

    geo_map = lookup_df.set_index("postal_code")[["lat", "lon"]]

    return pd.DataFrame({
        "lat": s.map(lambda x: geo_map.loc[x, "lat"] if x in geo_map.index else np.nan),
        "lon": s.map(lambda x: geo_map.loc[x, "lon"] if x in geo_map.index else np.nan),
    })


@log_execution(
    "alteryx",
    "fetch_w1_sales",
    "Transform ship-to raw data into inference-ready dat",
    cfg.LOG_FILE
)
def fetch_w1_sales(ship_to_raw: pd.DataFrame) -> pd.DataFrame:
    """
    Final inference dat.csv
    """
    df = ship_to_raw.copy()
    df = df[~df["Entpr_ID_5"].astype(str).str.contains("Open", na=False)]
    df["Total_Sales"] = pd.to_numeric(df["Total_Sales"], errors="coerce").fillna(0)

    dat = (
        df.groupby(["Ship_To_Customer", "SIG"], as_index=False)
        .agg({
            "Total_Sales": "sum",
            "Ship_To_Customer_Name": "first",
            "Ship_To_Street_Address": "first",
            "Ship_To_City": "first",
            "Ship_To_State": "first",
            "Ship_To_Postal_Code": "first",
            "Entpr_ID_3": "first",
            "Entpr_ID_4": "first",
            "Entpr_ID_5": "first",
            "Level3_Employee": "first",
            "Level4_Employee": "first",
            "Level5_Employee":"first",
        })
    )

    geo = _get_lat_lon_from_postal(dat["Ship_To_Postal_Code"])
    dat["lat"] = geo["lat"]
    dat["lon"] = geo["lon"]

    return dat


@log_execution(
    "alteryx",
    "build_dat_zip_from_snapshot",
    "Build sales_rep_data_v2 from sales-rep raw data",
    cfg.LOG_FILE
)
def build_dat_zip_from_snapshot(sales_rep_raw: pd.DataFrame) -> pd.DataFrame:
    """
    sales_rep_data_v2
    """
    df = sales_rep_raw.copy()
    df = df[~df["Entpr_ID_5"].astype(str).str.contains("Open", na=False)]
    df = df.drop_duplicates(subset=["Entpr_ID_5"])

    entprs = sorted(df["Entpr_ID_5"].astype(str).unique())
    entpr_map = {e: i for i, e in enumerate(entprs)}
    df["SIG_lvl5_int"] = df["Entpr_ID_5"].astype(str).map(entpr_map)

    geo = _get_lat_lon_from_postal(df["HOMEPOSTALCODE"])
    df["lat"] = geo["lat"]
    df["lon"] = geo["lon"]

    return df[
        ["Entpr_ID_5", "SIG_lvl5_int", "lat", "lon"]
    ]


@log_execution(
    "alteryx",
    "fetch_w4_sig_withnames",
    "Derive SIG-with-names from inference dat",
    cfg.LOG_FILE
)
def fetch_w4_sig_withnames(dat: pd.DataFrame) -> pd.DataFrame:
    """
    Derived SCSE_withnames (no SQL)
    """
    return (
        dat[["Entpr_ID_3", "Entpr_ID_4", "Entpr_ID_5", "SIG"]]
        .drop_duplicates()
        .reset_index(drop=True)
    )