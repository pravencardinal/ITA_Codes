from setuptools import find_packages, setup

setup(
    name='src',
    packages=find_packages(),
    version='0.1.0',
    description='predicts the lead time for source generic products',
    author='augintel pharma ML/AL',
    license='MIT',
)
