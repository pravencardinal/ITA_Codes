from airflow import DAG
from airflow.operators.email_operator import EmailOperator
from airflow.operators.python_operator import PythonOperator
from airflow import models
from datetime import timedelta, datetime
from airflow.utils.state import State
from airflow.exceptions import AirflowException
from airflow.utils.session import provide_session
from airflow.models import Variable
from google.cloud import aiplatform
import time

# =========================
# CONFIG  (KEEPING ITA TIMEOUT)
# =========================
TIMEOUT_MINUTES = 14440
DAGRUN_TIMEOUT_MIN = 14500

default_args = {
    'owner': 'medai',
    'description': 'ITA – Intelligent Territory Alignment Vertex AI Pipeline',
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag_name = "eddie_med_ai_ita_SCSE"
custom_job_name = "eddie_med_ai_ita_custom_job_SCSE"

# =========================
# ENV CONFIG  (UNCHANGED ITA VALUES)
# =========================
eddie_env = Variable.get("eddie_env")

if eddie_env == "TRN":
    schedule_interval = None
    project = "edd-trn-mdai-pr-cah"
    service_account = "sa-eddie-med-ai-ita@edd-trn-mdai-pr-cah.iam.gserviceaccount.com"
    container_uri = "gcr.io/edd-trn-cde-pr-cah/eddie-med-ai-ita:0.0.22"
    bucket_name = "cah-eddie-trn-med-ai-ita-np"
    destination_blob_name = 'cah-eddie-trn-med-ai-ita-np/test'
    location = "us-central1"
    email_to = ["sagar.virmani@cardinalhealth.com"]

elif eddie_env == "STG":
    schedule_interval = None
    project = "eddie-stg-pr-cah"
    service_account = "sa-eddie-med-ai-ita@eddie-stg-pr-cah.iam.gserviceaccount.com"
    container_uri = "gcr.io/eddie-stg-pr-cah/med-ai-ita:stg-0.0.12"
    bucket_name = "cah-eddie-stg-med-ai-ita-np"
    destination_blob_name = 'cah-eddie-stg-med-ai-ita-np/test'
    location = "us-central1"
    email_to = "g-ds-global-usmpd-mktg-sourcing@cardinalhealth.com"

elif eddie_env == "PRD":
    schedule_interval = None
    project = "eddie-pr-cah"
    service_account = "sa-eddie-med-ai-ita@eddie-pr-cah.iam.gserviceaccount.com"
    container_uri = "gcr.io/eddie-pr-cah/med-ai-ita:prd-0.0.1"
    bucket_name = "cah-eddie-prd-med-ai-ita-np"
    destination_blob_name = 'cah-eddie-prd-med-ai-ita-np/test'
    location = "us-central1"
    email_to = "g-ds-global-usmpd-mktg-sourcing@cardinalhealth.com"

# =========================
# COMMON (LIKE PWR DAG)
# =========================
BUCKET_URI = f"gs://{bucket_name}/{destination_blob_name}"
staging_bucket = f"{BUCKET_URI}"

worker_pool_specs = [{
    "machine_spec": {"machine_type": "n2-highcpu-16"},
    "replica_count": 1,
    "container_spec": {
        "image_uri": container_uri,
        "command": ["python", "scripts/main.py"],
    },
}]

def vertex_ai_custom_job():
    custom_job = aiplatform.CustomJob(
        display_name=custom_job_name,
        worker_pool_specs=worker_pool_specs,
        project=project,
        staging_bucket=staging_bucket,
        location=location,
        labels={'ml_use_case': 'ita','apmid':'31441','costcenter':'2060000932'},
    )
    custom_job.run(service_account=service_account)

# =========================
# WATCHDOG FUNCTION (PWR STYLE)
# =========================
@provide_session
def check_runtime(session=None, **context):
    dag_run = context['dag_run']
    ti = dag_run.get_task_instance(
        task_id='vertex_ai_custom_job_task',
        session=session
    )

    waited = 0
    poll_interval = 10
    timeout = TIMEOUT_MINUTES * 60

    while waited < timeout:
        ti.refresh_from_db()

        if ti.state == State.SUCCESS:
            return

        if ti.state in [State.FAILED, State.UPSTREAM_FAILED]:
            return

        if ti.state in [State.RUNNING, State.QUEUED]:
            time.sleep(poll_interval)
            waited += poll_interval
            continue

        time.sleep(poll_interval)
        waited += poll_interval

    raise AirflowException(
        f"Vertex job still running after {TIMEOUT_MINUTES} minutes"
    )

# =========================
# DAG DEFINITION (IDENTICAL TO PWR)
# =========================
with models.DAG(
    dag_name,
    default_args=default_args,
    access_control={'medai': {'can_read', 'can_edit'}},
    schedule_interval=schedule_interval,
    catchup=False,
    max_active_runs=1,
    dagrun_timeout=timedelta(minutes=DAGRUN_TIMEOUT_MIN)
) as dag:

    vertex_ai_run_job = PythonOperator(
        task_id='vertex_ai_custom_job_task',
        python_callable=vertex_ai_custom_job
    )

    success = EmailOperator(
        task_id="success_mail",
        trigger_rule="all_success",
        to=email_to,
        subject="SUCCESS: Vertex AI pipeline - " + custom_job_name,
        html_content="<p> Vertex AI pipeline completed successfully </p>"
    )

    error_email = EmailOperator(
        task_id="error_email",
        trigger_rule="one_failed",
        to=email_to,
        subject="FAILURE: Vertex AI pipeline - " + custom_job_name,
        html_content="<p> Vertex AI pipeline FAILED </p>"
    )

    runtime_watchdog = PythonOperator(
        task_id='runtime_watchdog',
        python_callable=check_runtime,
        retries=0
    )

    timeout_email = EmailOperator(
        task_id="timeout_email",
        trigger_rule="one_failed",
        to=email_to,
        subject=f"TIMEOUT: Vertex AI pipeline exceeded {TIMEOUT_MINUTES} minutes - " + custom_job_name,
        html_content=f"<p> DAG runtime exceeded {TIMEOUT_MINUTES} minutes </p>"
    )

    vertex_ai_run_job >> success
    vertex_ai_run_job >> error_email
    runtime_watchdog >> timeout_email
