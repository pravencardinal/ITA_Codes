ML Use Case Overview
--
please provide brief description about the ML use case


Folder Structure
----


```
├── DAG                         # Airflow DAGs
├── LICENSE
├── README.md
├── cah-repo-init.bat
├── cah-repo-init.sh
├── data                        
│   ├── external                # Data from third party sources
│   ├── interim                 # Intermediate data that has been transformed
│   ├── processed               # The final, canonical data sets for modeling
│   └── raw                     # The original, immutable data dump
├── docs                        # Project related documents
├── models                      # Trained and serialized models, model predictions, or model summaries
├── notebooks                   # Jupyter notebooks
├── reference                   # Data dictionaries, manuals, and all other explanatory materials
├── reports                     # Generated analysis as HTML, PDF, LaTeX, etc.
├── src                         # Pipeline get trigger to any changes to this folder
│   ├── Dockerfile              # docker file to build the image
│   ├── __init__.py 
│   ├── config                  # place holder for config files
│   │   └── config.env.stage
│   ├── data                    #  Scripts to download or generate data
│   │   └── __init__.py
│   ├── features                # Scripts to train models and then use trained models to make predictions
│   │   └── __init__.py
│   ├── goss.yaml               # Scripts to train models and then use trained models to make predictions
│   ├── models                  
│   │   ├── __init__.py
│   │   └── predict_model.py
│   ├── requirements.txt        # he requirements file for reproducing the analysis environment
│   └── setup.py                # makes project pip installable
└── test

```